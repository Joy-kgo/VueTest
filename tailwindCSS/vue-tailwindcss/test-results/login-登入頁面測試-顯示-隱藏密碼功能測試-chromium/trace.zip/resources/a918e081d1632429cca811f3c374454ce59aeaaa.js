import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginPage.vue");import { ref } from "/node_modules/.vite/deps/vue.js?v=97a18dde"

// 定義 emit 用於登入成功事件

const _sfc_main = {
  __name: 'LoginPage',
  emits: ['login-success'],
  setup(__props, { expose: __expose, emit: __emit }) {
  __expose();

const emit = __emit

// 表單資料
const username = ref('')
const password = ref('')
const rememberMe = ref(false)
const showPassword = ref(false)
const errorMessage = ref('')

// 表單提交處理
const handleLogin = () => {
  errorMessage.value = ''

  // 驗證欄位
  if (!username.value.trim()) {
    errorMessage.value = '請輸入帳號'
    return
  }

  if (!password.value.trim()) {
    errorMessage.value = '請輸入密碼'
    return
  }

  // 簡單驗證（未來可接 API）
  if (username.value === 'admin' && password.value === 'password') {
    // 處理記住我功能
    if (rememberMe.value) {
      localStorage.setItem('rememberMe', 'true')
      localStorage.setItem('username', username.value)
    }

    // 觸發登入成功事件
    emit('login-success', { username: username.value })
  } else {
    errorMessage.value = '帳號或密碼錯誤'
  }
}

// 切換密碼顯示狀態
const togglePasswordVisibility = () => {
  showPassword.value = !showPassword.value
}

const __returned__ = { emit, username, password, rememberMe, showPassword, errorMessage, handleLogin, togglePasswordVisibility, ref }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createCommentVNode as _createCommentVNode, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, normalizeStyle as _normalizeStyle, createElementVNode as _createElementVNode, vModelText as _vModelText, withDirectives as _withDirectives, vModelDynamic as _vModelDynamic, vModelCheckbox as _vModelCheckbox, toDisplayString as _toDisplayString, withModifiers as _withModifiers, pushScopeId as _pushScopeId, popScopeId as _popScopeId } from "/node_modules/.vite/deps/vue.js?v=97a18dde"

const _withScopeId = n => (_pushScopeId("data-v-1aea22a9"),n=n(),_popScopeId(),n)
const _hoisted_1 = { class: "relative min-h-screen bg-gradient-to-b from-gray-900 to-gray-700 flex items-center justify-center overflow-hidden" }
const _hoisted_2 = { class: "absolute inset-0 pointer-events-none" }
const _hoisted_3 = { class: "relative z-10 bg-white/10 backdrop-blur-md rounded-2xl shadow-2xl p-8 w-11/12 sm:max-w-md border border-white/20" }
const _hoisted_4 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/_createElementVNode("h1", { class: "text-3xl font-bold text-white text-center mb-8" }, "登入", -1 /* HOISTED */))
const _hoisted_5 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/_createElementVNode("label", {
  for: "username",
  class: "block text-white text-sm font-medium mb-2"
}, "帳號", -1 /* HOISTED */))
const _hoisted_6 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/_createElementVNode("label", {
  for: "password",
  class: "block text-white text-sm font-medium mb-2"
}, "密碼", -1 /* HOISTED */))
const _hoisted_7 = { class: "relative" }
const _hoisted_8 = ["type"]
const _hoisted_9 = { key: 0 }
const _hoisted_10 = { key: 1 }
const _hoisted_11 = { class: "flex items-center" }
const _hoisted_12 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/_createElementVNode("label", {
  for: "remember",
  class: "ml-2 text-white text-sm"
}, "記住我", -1 /* HOISTED */))
const _hoisted_13 = {
  key: 0,
  class: "bg-red-500/20 border border-red-500/50 text-red-200 px-4 py-3 rounded-lg text-sm"
}
const _hoisted_14 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/_createElementVNode("button", {
  type: "submit",
  class: "w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors duration-300"
}, " 登入 ", -1 /* HOISTED */))

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createCommentVNode(" 下雪效果 "),
    _createElementVNode("div", _hoisted_2, [
      (_openBlock(), _createElementBlock(_Fragment, null, _renderList(40, (i) => {
        return _createElementVNode("div", {
          key: i,
          class: "snowflake",
          style: _normalizeStyle({
          left: `${Math.random() * 100}%`,
          animationDelay: `${Math.random() * 10}s`,
          animationDuration: `${10 + Math.random() * 10}s`,
          fontSize: `${10 + Math.random() * 10}px`,
        })
        }, " ❄ ", 4 /* STYLE */)
      }), 64 /* STABLE_FRAGMENT */))
    ]),
    _createCommentVNode(" 登入卡片 "),
    _createElementVNode("div", _hoisted_3, [
      _hoisted_4,
      _createElementVNode("form", {
        onSubmit: _withModifiers($setup.handleLogin, ["prevent"]),
        class: "space-y-6"
      }, [
        _createCommentVNode(" 帳號輸入框 "),
        _createElementVNode("div", null, [
          _hoisted_5,
          _withDirectives(_createElementVNode("input", {
            id: "username",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.username) = $event)),
            type: "text",
            class: "w-full px-4 py-3 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400",
            placeholder: "請輸入帳號"
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.username]
          ])
        ]),
        _createCommentVNode(" 密碼輸入框 "),
        _createElementVNode("div", null, [
          _hoisted_6,
          _createElementVNode("div", _hoisted_7, [
            _withDirectives(_createElementVNode("input", {
              id: "password",
              "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.password) = $event)),
              type: $setup.showPassword ? 'text' : 'password',
              class: "w-full px-4 py-3 bg-white/20 backdrop-blur-sm border border-white/30 rounded-lg text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 pr-12",
              placeholder: "請輸入密碼"
            }, null, 8 /* PROPS */, _hoisted_8), [
              [_vModelDynamic, $setup.password]
            ]),
            _createElementVNode("button", {
              type: "button",
              onClick: $setup.togglePasswordVisibility,
              class: "absolute right-3 top-1/2 -translate-y-1/2 text-white/70 hover:text-white focus:outline-none"
            }, [
              ($setup.showPassword)
                ? (_openBlock(), _createElementBlock("span", _hoisted_9, "👁️"))
                : (_openBlock(), _createElementBlock("span", _hoisted_10, "👁️‍🗨️"))
            ])
          ])
        ]),
        _createCommentVNode(" 記住我 "),
        _createElementVNode("div", _hoisted_11, [
          _withDirectives(_createElementVNode("input", {
            id: "remember",
            "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.rememberMe) = $event)),
            type: "checkbox",
            class: "w-4 h-4 rounded border-white/30 bg-white/20 text-blue-600 focus:ring-2 focus:ring-blue-400"
          }, null, 512 /* NEED_PATCH */), [
            [_vModelCheckbox, $setup.rememberMe]
          ]),
          _hoisted_12
        ]),
        _createCommentVNode(" 錯誤訊息 "),
        ($setup.errorMessage)
          ? (_openBlock(), _createElementBlock("div", _hoisted_13, _toDisplayString($setup.errorMessage), 1 /* TEXT */))
          : _createCommentVNode("v-if", true),
        _createCommentVNode(" 登入按鈕 "),
        _hoisted_14
      ], 32 /* NEED_HYDRATION */)
    ])
  ]))
}

import "/src/components/LoginPage.vue?vue&type=style&index=0&scoped=1aea22a9&lang.css"

_sfc_main.__hmrId = "1aea22a9"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-1aea22a9"],['__file',"D:/Tests/VueTest/tailwindCSS/vue-tailwindcss/src/components/LoginPage.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW5QYWdlLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwPlxuaW1wb3J0IHsgcmVmIH0gZnJvbSAndnVlJ1xuXG4vLyDlrprnvqkgZW1pdCDnlKjmlrznmbvlhaXmiJDlip/kuovku7ZcbmNvbnN0IGVtaXQgPSBkZWZpbmVFbWl0cyhbJ2xvZ2luLXN1Y2Nlc3MnXSlcblxuLy8g6KGo5Zau6LOH5paZXG5jb25zdCB1c2VybmFtZSA9IHJlZignJylcbmNvbnN0IHBhc3N3b3JkID0gcmVmKCcnKVxuY29uc3QgcmVtZW1iZXJNZSA9IHJlZihmYWxzZSlcbmNvbnN0IHNob3dQYXNzd29yZCA9IHJlZihmYWxzZSlcbmNvbnN0IGVycm9yTWVzc2FnZSA9IHJlZignJylcblxuLy8g6KGo5Zau5o+Q5Lqk6JmV55CGXG5jb25zdCBoYW5kbGVMb2dpbiA9ICgpID0+IHtcbiAgZXJyb3JNZXNzYWdlLnZhbHVlID0gJydcblxuICAvLyDpqZforYnmrITkvY1cbiAgaWYgKCF1c2VybmFtZS52YWx1ZS50cmltKCkpIHtcbiAgICBlcnJvck1lc3NhZ2UudmFsdWUgPSAn6KuL6Ly45YWl5biz6JmfJ1xuICAgIHJldHVyblxuICB9XG5cbiAgaWYgKCFwYXNzd29yZC52YWx1ZS50cmltKCkpIHtcbiAgICBlcnJvck1lc3NhZ2UudmFsdWUgPSAn6KuL6Ly45YWl5a+G56K8J1xuICAgIHJldHVyblxuICB9XG5cbiAgLy8g57Ch5Zau6amX6K2J77yI5pyq5L6G5Y+v5o6lIEFQSe+8iVxuICBpZiAodXNlcm5hbWUudmFsdWUgPT09ICdhZG1pbicgJiYgcGFzc3dvcmQudmFsdWUgPT09ICdwYXNzd29yZCcpIHtcbiAgICAvLyDomZXnkIboqJjkvY/miJHlip/og71cbiAgICBpZiAocmVtZW1iZXJNZS52YWx1ZSkge1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3JlbWVtYmVyTWUnLCAndHJ1ZScpXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndXNlcm5hbWUnLCB1c2VybmFtZS52YWx1ZSlcbiAgICB9XG5cbiAgICAvLyDop7jnmbznmbvlhaXmiJDlip/kuovku7ZcbiAgICBlbWl0KCdsb2dpbi1zdWNjZXNzJywgeyB1c2VybmFtZTogdXNlcm5hbWUudmFsdWUgfSlcbiAgfSBlbHNlIHtcbiAgICBlcnJvck1lc3NhZ2UudmFsdWUgPSAn5biz6Jmf5oiW5a+G56K86Yyv6KqkJ1xuICB9XG59XG5cbi8vIOWIh+aPm+WvhueivOmhr+ekuueLgOaFi1xuY29uc3QgdG9nZ2xlUGFzc3dvcmRWaXNpYmlsaXR5ID0gKCkgPT4ge1xuICBzaG93UGFzc3dvcmQudmFsdWUgPSAhc2hvd1Bhc3N3b3JkLnZhbHVlXG59XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgbWluLWgtc2NyZWVuIGJnLWdyYWRpZW50LXRvLWIgZnJvbS1ncmF5LTkwMCB0by1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICA8IS0tIOS4i+mbquaViOaenCAtLT5cbiAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgaW5zZXQtMCBwb2ludGVyLWV2ZW50cy1ub25lXCI+XG4gICAgICA8ZGl2XG4gICAgICAgIHYtZm9yPVwiaSBpbiA0MFwiXG4gICAgICAgIDprZXk9XCJpXCJcbiAgICAgICAgY2xhc3M9XCJzbm93Zmxha2VcIlxuICAgICAgICA6c3R5bGU9XCJ7XG4gICAgICAgICAgbGVmdDogYCR7TWF0aC5yYW5kb20oKSAqIDEwMH0lYCxcbiAgICAgICAgICBhbmltYXRpb25EZWxheTogYCR7TWF0aC5yYW5kb20oKSAqIDEwfXNgLFxuICAgICAgICAgIGFuaW1hdGlvbkR1cmF0aW9uOiBgJHsxMCArIE1hdGgucmFuZG9tKCkgKiAxMH1zYCxcbiAgICAgICAgICBmb250U2l6ZTogYCR7MTAgKyBNYXRoLnJhbmRvbSgpICogMTB9cHhgLFxuICAgICAgICB9XCJcbiAgICAgID5cbiAgICAgICAg4p2EXG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cblxuICAgIDwhLS0g55m75YWl5Y2h54mHIC0tPlxuICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSB6LTEwIGJnLXdoaXRlLzEwIGJhY2tkcm9wLWJsdXItbWQgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBwLTggdy0xMS8xMiBzbTptYXgtdy1tZCBib3JkZXIgYm9yZGVyLXdoaXRlLzIwXCI+XG4gICAgICA8aDEgY2xhc3M9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LWNlbnRlciBtYi04XCI+55m75YWlPC9oMT5cblxuICAgICAgPGZvcm0gQHN1Ym1pdC5wcmV2ZW50PVwiaGFuZGxlTG9naW5cIiBjbGFzcz1cInNwYWNlLXktNlwiPlxuICAgICAgICA8IS0tIOW4s+iZn+i8uOWFpeahhiAtLT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8bGFiZWwgZm9yPVwidXNlcm5hbWVcIiBjbGFzcz1cImJsb2NrIHRleHQtd2hpdGUgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0yXCI+5biz6JmfPC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGlkPVwidXNlcm5hbWVcIlxuICAgICAgICAgICAgdi1tb2RlbD1cInVzZXJuYW1lXCJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIGNsYXNzPVwidy1mdWxsIHB4LTQgcHktMyBiZy13aGl0ZS8yMCBiYWNrZHJvcC1ibHVyLXNtIGJvcmRlciBib3JkZXItd2hpdGUvMzAgcm91bmRlZC1sZyB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLWdyYXktMzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTQwMFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuiri+i8uOWFpeW4s+iZn1wiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPCEtLSDlr4bnorzovLjlhaXmoYYgLS0+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGxhYmVsIGZvcj1cInBhc3N3b3JkXCIgY2xhc3M9XCJibG9jayB0ZXh0LXdoaXRlIHRleHQtc20gZm9udC1tZWRpdW0gbWItMlwiPuWvhueivDwvbGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIHYtbW9kZWw9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgIDp0eXBlPVwic2hvd1Bhc3N3b3JkID8gJ3RleHQnIDogJ3Bhc3N3b3JkJ1wiXG4gICAgICAgICAgICAgIGNsYXNzPVwidy1mdWxsIHB4LTQgcHktMyBiZy13aGl0ZS8yMCBiYWNrZHJvcC1ibHVyLXNtIGJvcmRlciBib3JkZXItd2hpdGUvMzAgcm91bmRlZC1sZyB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLWdyYXktMzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTQwMCBwci0xMlwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi6KuL6Ly45YWl5a+G56K8XCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBAY2xpY2s9XCJ0b2dnbGVQYXNzd29yZFZpc2liaWxpdHlcIlxuICAgICAgICAgICAgICBjbGFzcz1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtd2hpdGUvNzAgaG92ZXI6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiB2LWlmPVwic2hvd1Bhc3N3b3JkXCI+8J+Rge+4jzwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gdi1lbHNlPvCfkYHvuI/igI3wn5eo77iPPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwhLS0g6KiY5L2P5oiRIC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGlkPVwicmVtZW1iZXJcIlxuICAgICAgICAgICAgdi1tb2RlbD1cInJlbWVtYmVyTWVcIlxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgIGNsYXNzPVwidy00IGgtNCByb3VuZGVkIGJvcmRlci13aGl0ZS8zMCBiZy13aGl0ZS8yMCB0ZXh0LWJsdWUtNjAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNDAwXCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxsYWJlbCBmb3I9XCJyZW1lbWJlclwiIGNsYXNzPVwibWwtMiB0ZXh0LXdoaXRlIHRleHQtc21cIj7oqJjkvY/miJE8L2xhYmVsPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8IS0tIOmMr+iqpOioiuaBryAtLT5cbiAgICAgICAgPGRpdiB2LWlmPVwiZXJyb3JNZXNzYWdlXCIgY2xhc3M9XCJiZy1yZWQtNTAwLzIwIGJvcmRlciBib3JkZXItcmVkLTUwMC81MCB0ZXh0LXJlZC0yMDAgcHgtNCBweS0zIHJvdW5kZWQtbGcgdGV4dC1zbVwiPlxuICAgICAgICAgIHt7IGVycm9yTWVzc2FnZSB9fVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8IS0tIOeZu+WFpeaMiemIlSAtLT5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgIGNsYXNzPVwidy1mdWxsIHB5LTMgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwXCJcbiAgICAgICAgPlxuICAgICAgICAgIOeZu+WFpVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG48L3RlbXBsYXRlPlxuXG48c3R5bGUgc2NvcGVkPlxuLnNub3dmbGFrZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAtMTBweDtcbiAgY29sb3I6IHdoaXRlO1xuICBvcGFjaXR5OiAwLjg7XG4gIHVzZXItc2VsZWN0OiBub25lO1xuICBhbmltYXRpb246IGZhbGwgbGluZWFyIGluZmluaXRlO1xuICB3aWxsLWNoYW5nZTogdHJhbnNmb3JtO1xufVxuXG5Aa2V5ZnJhbWVzIGZhbGwge1xuICB0byB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwMHZoKTtcbiAgfVxufVxuXG4vKiDlsIrph43kvb/nlKjogIXnmoTli5XnlavlgY/lpb0gKi9cbkBtZWRpYSAocHJlZmVycy1yZWR1Y2VkLW1vdGlvbjogcmVkdWNlKSB7XG4gIC5zbm93Zmxha2Uge1xuICAgIGFuaW1hdGlvbjogbm9uZTtcbiAgfVxufVxuPC9zdHlsZT5cbiJdLCJtYXBwaW5ncyI6IkFBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7QUFITDtBQUlkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBOEI7QUFDM0M7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDOzs7Ozs7Ozs7OztxQkFJTSxLQUFLLEVBQUMsbUhBQW1IO3FCQUV2SCxLQUFLLEVBQUMsc0NBQXNDO3FCQWlCNUMsS0FBSyxFQUFDLGtIQUFrSDtpRUFDM0gsb0JBQWtFLFFBQTlELEtBQUssRUFBQyxnREFBZ0QsSUFBQyxJQUFFO2lFQUt6RCxvQkFBa0Y7RUFBM0UsR0FBRyxFQUFDLFVBQVU7RUFBQyxLQUFLLEVBQUMsMkNBQTJDO0dBQUMsSUFBRTtpRUFZMUUsb0JBQWtGO0VBQTNFLEdBQUcsRUFBQyxVQUFVO0VBQUMsS0FBSyxFQUFDLDJDQUEyQztHQUFDLElBQUU7cUJBQ3JFLEtBQUssRUFBQyxVQUFVO21CQXhGL0I7cUJBQUEsS0FBQTtzQkFBQSxLQUFBO3NCQTRHYSxLQUFLLEVBQUMsbUJBQW1CO2tFQU81QixvQkFBaUU7RUFBMUQsR0FBRyxFQUFDLFVBQVU7RUFBQyxLQUFLLEVBQUMseUJBQXlCO0dBQUMsS0FBRzs7RUFuSG5FLEtBQUE7RUF1SGlDLEtBQUssRUFBQyxrRkFBa0Y7O2tFQUtqSCxvQkFLUztFQUpQLElBQUksRUFBQyxRQUFRO0VBQ2IsS0FBSyxFQUFDLDhHQUE4RztHQUNySCxNQUVEOzs7d0JBL0VOLG9CQWtGTSxPQWxGTixVQWtGTTtJQWpGSiw2QkFBYTtJQUNiLG9CQWNNLE9BZE4sVUFjTTtxQkFiSixvQkFZTSxpQkFqRVosWUFzRG9CLEVBQUUsRUF0RHRCLENBc0RlLENBQUM7ZUFEVixvQkFZTTtVQVZILEdBQUcsRUFBRSxDQUFDO1VBQ1AsS0FBSyxFQUFDLFdBQVc7VUFDaEIsS0FBSyxFQXpEZDttQkF5RHFDLElBQUksQ0FBQyxNQUFNOzZCQUEwQyxJQUFJLENBQUMsTUFBTTtxQ0FBaUQsSUFBSSxDQUFDLE1BQU07NEJBQXdDLElBQUksQ0FBQyxNQUFNOztXQU03TSxLQUVEOzs7SUFHRiw2QkFBYTtJQUNiLG9CQThETSxPQTlETixVQThETTtNQTdESixVQUFrRTtNQUVsRSxvQkEwRE87UUExREEsUUFBTSxFQXhFbkIsZUF3RTZCLGtCQUFXO1FBQUUsS0FBSyxFQUFDLFdBQVc7O1FBQ25ELDhCQUFjO1FBQ2Qsb0JBU007VUFSSixVQUFrRjswQkFDbEYsb0JBTUU7WUFMQSxFQUFFLEVBQUMsVUFBVTtZQTdFekIsNkRBOEVxQixlQUFRO1lBQ2pCLElBQUksRUFBQyxNQUFNO1lBQ1gsS0FBSyxFQUFDLHFLQUFxSztZQUMzSyxXQUFXLEVBQUMsT0FBTzs7MEJBSFYsZUFBUTs7O1FBT3JCLDhCQUFjO1FBQ2Qsb0JBbUJNO1VBbEJKLFVBQWtGO1VBQ2xGLG9CQWdCTSxPQWhCTixVQWdCTTs0QkFmSixvQkFNRTtjQUxBLEVBQUUsRUFBQyxVQUFVO2NBMUYzQiw2REEyRnVCLGVBQVE7Y0FDaEIsSUFBSSxFQUFFLG1CQUFZO2NBQ25CLEtBQUssRUFBQywyS0FBMks7Y0FDakwsV0FBVyxFQUFDLE9BQU87b0NBOUZqQzsrQkEyRnVCLGVBQVE7O1lBS25CLG9CQU9TO2NBTlAsSUFBSSxFQUFDLFFBQVE7Y0FDWixPQUFLLEVBQUUsK0JBQXdCO2NBQ2hDLEtBQUssRUFBQyw2RkFBNkY7O2VBRXZGLG1CQUFZO2lDQUF4QixvQkFBb0MsUUFyR2xELFlBcUd3QyxLQUFHO2lDQUM3QixvQkFBMkIsUUF0R3pDLGFBc0cyQixTQUFPOzs7O1FBSzFCLDRCQUFZO1FBQ1osb0JBUU0sT0FSTixXQVFNOzBCQVBKLG9CQUtFO1lBSkEsRUFBRSxFQUFDLFVBQVU7WUE5R3pCLDZEQStHcUIsaUJBQVU7WUFDbkIsSUFBSSxFQUFDLFVBQVU7WUFDZixLQUFLLEVBQUMsNEZBQTRGOzs4QkFGekYsaUJBQVU7O1VBSXJCLFdBQWlFOztRQUduRSw2QkFBYTtTQUNGLG1CQUFZOzJCQUF2QixvQkFFTSxPQUZOLFdBRU0sbUJBREQsbUJBQVk7WUF4SHpCO1FBMkhRLDZCQUFhO1FBQ2IsV0FLUyJ9