import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ChristmasTree.vue");
const _sfc_main = {
  __name: 'ChristmasTree',
  emits: ['logout'],
  setup(__props, { expose: __expose, emit: __emit }) {
  __expose();

// 定義 emit 用於登出事件
const emit = __emit

// 登出處理函式
const handleLogout = () => {
  emit('logout')
}

const __returned__ = { emit, handleLogout }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createCommentVNode as _createCommentVNode, createElementVNode as _createElementVNode, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, normalizeStyle as _normalizeStyle, createStaticVNode as _createStaticVNode, pushScopeId as _pushScopeId, popScopeId as _popScopeId } from "/node_modules/.vite/deps/vue.js?v=97a18dde"

const _withScopeId = n => (_pushScopeId("data-v-df50c1b1"),n=n(),_popScopeId(),n)
const _hoisted_1 = { class: "christmas-container" }
const _hoisted_2 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/_createElementVNode("div", { class: "night-sky" }, null, -1 /* HOISTED */))
const _hoisted_3 = {
  class: "snowflakes",
  "aria-hidden": "true"
}
const _hoisted_4 = /*#__PURE__*/_createStaticVNode("<div class=\"tree-wrapper\" data-v-df50c1b1><!-- 星星 --><div class=\"star\" data-v-df50c1b1>⭐</div><!-- 樹的三角形層次 --><div class=\"tree-section\" data-v-df50c1b1><!-- 第一層（最小） --><div class=\"tree-layer layer-small\" data-v-df50c1b1><div class=\"lights\" data-v-df50c1b1><span class=\"light red\" data-v-df50c1b1>●</span><span class=\"light yellow\" data-v-df50c1b1>●</span><span class=\"light blue\" data-v-df50c1b1>●</span></div></div><!-- 第二層 --><div class=\"tree-layer layer-medium\" data-v-df50c1b1><div class=\"lights\" data-v-df50c1b1><span class=\"light yellow\" data-v-df50c1b1>●</span><span class=\"light green\" data-v-df50c1b1>●</span><span class=\"light red\" data-v-df50c1b1>●</span><span class=\"light blue\" data-v-df50c1b1>●</span><span class=\"light pink\" data-v-df50c1b1>●</span></div></div><!-- 第三層（最大） --><div class=\"tree-layer layer-large\" data-v-df50c1b1><div class=\"lights\" data-v-df50c1b1><span class=\"light blue\" data-v-df50c1b1>●</span><span class=\"light red\" data-v-df50c1b1>●</span><span class=\"light yellow\" data-v-df50c1b1>●</span><span class=\"light green\" data-v-df50c1b1>●</span><span class=\"light pink\" data-v-df50c1b1>●</span><span class=\"light blue\" data-v-df50c1b1>●</span><span class=\"light red\" data-v-df50c1b1>●</span></div></div></div><!-- 樹幹 --><div class=\"trunk\" data-v-df50c1b1></div><!-- 禮物 --><div class=\"gifts\" data-v-df50c1b1><div class=\"gift\" data-v-df50c1b1>🎁</div><div class=\"gift\" data-v-df50c1b1>🎁</div><div class=\"gift\" data-v-df50c1b1>🎁</div></div></div>", 1)
const _hoisted_5 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/_createElementVNode("div", { class: "message" }, [
  /*#__PURE__*/_createElementVNode("h1", null, "🎄 聖誕快樂 🎄"),
  /*#__PURE__*/_createElementVNode("p", null, "Merry Christmas!")
], -1 /* HOISTED */))

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createCommentVNode(" 登出按鈕 "),
    _createElementVNode("button", {
      onClick: $setup.handleLogout,
      class: "logout-button",
      "aria-label": "登出"
    }, " 登出 "),
    _createCommentVNode(" 夜晚背景 "),
    _hoisted_2,
    _createCommentVNode(" 下雪效果 "),
    _createElementVNode("div", _hoisted_3, [
      (_openBlock(), _createElementBlock(_Fragment, null, _renderList(50, (n) => {
        return _createElementVNode("div", {
          key: n,
          class: "snowflake",
          style: _normalizeStyle({
          left: `${Math.random() * 100}%`,
          animationDelay: `${Math.random() * 10}s`,
          animationDuration: `${10 + Math.random() * 10}s`,
          fontSize: `${10 + Math.random() * 10}px`
        })
        }, " ❅ ", 4 /* STYLE */)
      }), 64 /* STABLE_FRAGMENT */))
    ]),
    _createCommentVNode(" 聖誕樹 "),
    _hoisted_4,
    _createCommentVNode(" 祝福文字 "),
    _hoisted_5
  ]))
}

import "/src/components/ChristmasTree.vue?vue&type=style&index=0&scoped=df50c1b1&lang.css"

_sfc_main.__hmrId = "df50c1b1"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-df50c1b1"],['__file',"D:/Tests/VueTest/tailwindCSS/vue-tailwindcss/src/components/ChristmasTree.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2hyaXN0bWFzVHJlZS52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cbi8vIOWumue+qSBlbWl0IOeUqOaWvOeZu+WHuuS6i+S7tlxuY29uc3QgZW1pdCA9IGRlZmluZUVtaXRzKFsnbG9nb3V0J10pXG5cbi8vIOeZu+WHuuiZleeQhuWHveW8j1xuY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xuICBlbWl0KCdsb2dvdXQnKVxufVxuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cbiAgPGRpdiBjbGFzcz1cImNocmlzdG1hcy1jb250YWluZXJcIj5cbiAgICA8IS0tIOeZu+WHuuaMiemIlSAtLT5cbiAgICA8YnV0dG9uXG4gICAgICBAY2xpY2s9XCJoYW5kbGVMb2dvdXRcIlxuICAgICAgY2xhc3M9XCJsb2dvdXQtYnV0dG9uXCJcbiAgICAgIGFyaWEtbGFiZWw9XCLnmbvlh7pcIlxuICAgID5cbiAgICAgIOeZu+WHulxuICAgIDwvYnV0dG9uPlxuXG4gICAgPCEtLSDlpJzmmZrog4zmma8gLS0+XG4gICAgPGRpdiBjbGFzcz1cIm5pZ2h0LXNreVwiPjwvZGl2PlxuXG4gICAgPCEtLSDkuIvpm6rmlYjmnpwgLS0+XG4gICAgPGRpdiBjbGFzcz1cInNub3dmbGFrZXNcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgIDxkaXZcbiAgICAgICAgdi1mb3I9XCJuIGluIDUwXCJcbiAgICAgICAgOmtleT1cIm5cIlxuICAgICAgICBjbGFzcz1cInNub3dmbGFrZVwiXG4gICAgICAgIDpzdHlsZT1cIntcbiAgICAgICAgICBsZWZ0OiBgJHtNYXRoLnJhbmRvbSgpICogMTAwfSVgLFxuICAgICAgICAgIGFuaW1hdGlvbkRlbGF5OiBgJHtNYXRoLnJhbmRvbSgpICogMTB9c2AsXG4gICAgICAgICAgYW5pbWF0aW9uRHVyYXRpb246IGAkezEwICsgTWF0aC5yYW5kb20oKSAqIDEwfXNgLFxuICAgICAgICAgIGZvbnRTaXplOiBgJHsxMCArIE1hdGgucmFuZG9tKCkgKiAxMH1weGBcbiAgICAgICAgfVwiXG4gICAgICA+XG4gICAgICAgIOKdhVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG5cbiAgICA8IS0tIOiBluiqleaouSAtLT5cbiAgICA8ZGl2IGNsYXNzPVwidHJlZS13cmFwcGVyXCI+XG4gICAgICA8IS0tIOaYn+aYnyAtLT5cbiAgICAgIDxkaXYgY2xhc3M9XCJzdGFyXCI+4q2QPC9kaXY+XG5cbiAgICAgIDwhLS0g5qi555qE5LiJ6KeS5b2i5bGk5qyhIC0tPlxuICAgICAgPGRpdiBjbGFzcz1cInRyZWUtc2VjdGlvblwiPlxuICAgICAgICA8IS0tIOesrOS4gOWxpO+8iOacgOWwj++8iSAtLT5cbiAgICAgICAgPGRpdiBjbGFzcz1cInRyZWUtbGF5ZXIgbGF5ZXItc21hbGxcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibGlnaHRzXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImxpZ2h0IHJlZFwiPuKXjzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGlnaHQgeWVsbG93XCI+4pePPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsaWdodCBibHVlXCI+4pePPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8IS0tIOesrOS6jOWxpCAtLT5cbiAgICAgICAgPGRpdiBjbGFzcz1cInRyZWUtbGF5ZXIgbGF5ZXItbWVkaXVtXCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImxpZ2h0c1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsaWdodCB5ZWxsb3dcIj7il488L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImxpZ2h0IGdyZWVuXCI+4pePPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsaWdodCByZWRcIj7il488L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImxpZ2h0IGJsdWVcIj7il488L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImxpZ2h0IHBpbmtcIj7il488L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwhLS0g56ys5LiJ5bGk77yI5pyA5aSn77yJIC0tPlxuICAgICAgICA8ZGl2IGNsYXNzPVwidHJlZS1sYXllciBsYXllci1sYXJnZVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJsaWdodHNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGlnaHQgYmx1ZVwiPuKXjzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwibGlnaHQgcmVkXCI+4pePPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsaWdodCB5ZWxsb3dcIj7il488L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cImxpZ2h0IGdyZWVuXCI+4pePPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsaWdodCBwaW5rXCI+4pePPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsaWdodCBibHVlXCI+4pePPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJsaWdodCByZWRcIj7il488L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDwhLS0g5qi55bm5IC0tPlxuICAgICAgPGRpdiBjbGFzcz1cInRydW5rXCI+PC9kaXY+XG5cbiAgICAgIDwhLS0g56au54mpIC0tPlxuICAgICAgPGRpdiBjbGFzcz1cImdpZnRzXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJnaWZ0XCI+8J+OgTwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZ2lmdFwiPvCfjoE8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImdpZnRcIj7wn46BPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cblxuICAgIDwhLS0g56Wd56aP5paH5a2XIC0tPlxuICAgIDxkaXYgY2xhc3M9XCJtZXNzYWdlXCI+XG4gICAgICA8aDE+8J+OhCDogZboqpXlv6vmqIIg8J+OhDwvaDE+XG4gICAgICA8cD5NZXJyeSBDaHJpc3RtYXMhPC9wPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzdHlsZSBzY29wZWQ+XG4uY2hyaXN0bWFzLWNvbnRhaW5lciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbWluLWhlaWdodDogMTAwdmg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4ubmlnaHQtc2t5IHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICMwYTE5MjkgMCUsICMxYTIzN2UgNTAlLCAjMjgzNTkzIDEwMCUpO1xuICB6LWluZGV4OiAxO1xufVxuXG4vKiDkuIvpm6rmlYjmnpwgKi9cbi5zbm93Zmxha2VzIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IC0xMCU7XG4gIGxlZnQ6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDExMCU7XG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICB6LWluZGV4OiAyO1xufVxuXG4uc25vd2ZsYWtlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IC0xMCU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgb3BhY2l0eTogMC44O1xuICB1c2VyLXNlbGVjdDogbm9uZTtcbiAgYW5pbWF0aW9uOiBmYWxsIGxpbmVhciBpbmZpbml0ZTtcbiAgd2lsbC1jaGFuZ2U6IHRyYW5zZm9ybTtcbn1cblxuQGtleWZyYW1lcyBmYWxsIHtcbiAgdG8ge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMTB2aCk7XG4gICAgb3BhY2l0eTogMC4zO1xuICB9XG59XG5cbi8qIOiBluiqleaouSAqL1xuLnRyZWUtd3JhcHBlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMztcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZ2FwOiAtMjBweDtcbn1cblxuLnN0YXIge1xuICBmb250LXNpemU6IDRyZW07XG4gIGFuaW1hdGlvbjogdHdpbmtsZSAxLjVzIGVhc2UtaW4tb3V0IGluZmluaXRlO1xuICBmaWx0ZXI6IGRyb3Atc2hhZG93KDAgMCAxMHB4IGdvbGQpO1xufVxuXG5Aa2V5ZnJhbWVzIHR3aW5rbGUge1xuICAwJSwgMTAwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxuICA1MCUge1xuICAgIG9wYWNpdHk6IDAuNTtcbiAgfVxufVxuXG4udHJlZS1zZWN0aW9uIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZ2FwOiAtMzBweDtcbn1cblxuLnRyZWUtbGF5ZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICMyZDUwMTYsICMxYTNkMGEpO1xuICBjbGlwLXBhdGg6IHBvbHlnb24oNTAlIDAlLCAwJSAxMDAlLCAxMDAlIDEwMCUpO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLmxheWVyLXNtYWxsIHtcbiAgd2lkdGg6IDE1MHB4O1xuICBoZWlnaHQ6IDEyMHB4O1xufVxuXG4ubGF5ZXItbWVkaXVtIHtcbiAgd2lkdGg6IDI1MHB4O1xuICBoZWlnaHQ6IDE4MHB4O1xufVxuXG4ubGF5ZXItbGFyZ2Uge1xuICB3aWR0aDogMzUwcHg7XG4gIGhlaWdodDogMjQwcHg7XG59XG5cbi5saWdodHMge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiA5MCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xuICBmbGV4LXdyYXA6IHdyYXA7XG4gIGdhcDogMTBweDtcbiAgcGFkZGluZzogMjBweDtcbn1cblxuLmxpZ2h0IHtcbiAgZm9udC1zaXplOiAxLjJyZW07XG4gIGFuaW1hdGlvbjogYmxpbmsgMS41cyBlYXNlLWluLW91dCBpbmZpbml0ZTtcbiAgZmlsdGVyOiBkcm9wLXNoYWRvdygwIDAgNXB4IGN1cnJlbnRDb2xvcik7XG59XG5cbi5saWdodC5yZWQge1xuICBjb2xvcjogI2ZmNDQ0NDtcbiAgYW5pbWF0aW9uLWRlbGF5OiAwcztcbn1cblxuLmxpZ2h0LnllbGxvdyB7XG4gIGNvbG9yOiAjZmZlYjNiO1xuICBhbmltYXRpb24tZGVsYXk6IDAuM3M7XG59XG5cbi5saWdodC5ibHVlIHtcbiAgY29sb3I6ICMyMTk2ZjM7XG4gIGFuaW1hdGlvbi1kZWxheTogMC42cztcbn1cblxuLmxpZ2h0LmdyZWVuIHtcbiAgY29sb3I6ICM0Y2FmNTA7XG4gIGFuaW1hdGlvbi1kZWxheTogMC45cztcbn1cblxuLmxpZ2h0LnBpbmsge1xuICBjb2xvcjogI2ZmNjliNDtcbiAgYW5pbWF0aW9uLWRlbGF5OiAxLjJzO1xufVxuXG5Aa2V5ZnJhbWVzIGJsaW5rIHtcbiAgMCUsIDEwMCUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbiAgNTAlIHtcbiAgICBvcGFjaXR5OiAwLjI7XG4gIH1cbn1cblxuLnRydW5rIHtcbiAgd2lkdGg6IDgwcHg7XG4gIGhlaWdodDogMTAwcHg7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM1ZDQwMzcsICMzZTI3MjMpO1xuICBib3JkZXItcmFkaXVzOiAwIDAgMTBweCAxMHB4O1xuICBib3gtc2hhZG93OiAwIDRweCA4cHggcmdiYSgwLCAwLCAwLCAwLjMpO1xufVxuXG4uZ2lmdHMge1xuICBkaXNwbGF5OiBmbGV4O1xuICBnYXA6IDIwcHg7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbi5naWZ0IHtcbiAgZm9udC1zaXplOiAzcmVtO1xuICBhbmltYXRpb246IGJvdW5jZSAycyBlYXNlLWluLW91dCBpbmZpbml0ZTtcbn1cblxuLmdpZnQ6bnRoLWNoaWxkKDEpIHtcbiAgYW5pbWF0aW9uLWRlbGF5OiAwcztcbn1cblxuLmdpZnQ6bnRoLWNoaWxkKDIpIHtcbiAgYW5pbWF0aW9uLWRlbGF5OiAwLjNzO1xufVxuXG4uZ2lmdDpudGgtY2hpbGQoMykge1xuICBhbmltYXRpb24tZGVsYXk6IDAuNnM7XG59XG5cbkBrZXlmcmFtZXMgYm91bmNlIHtcbiAgMCUsIDEwMCUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTtcbiAgfVxuICA1MCUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMTVweCk7XG4gIH1cbn1cblxuLm1lc3NhZ2Uge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHotaW5kZXg6IDM7XG4gIG1hcmdpbi10b3A6IDRyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4ubWVzc2FnZSBoMSB7XG4gIGZvbnQtc2l6ZTogMi41cmVtO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luLWJvdHRvbTogMC41cmVtO1xuICBhbmltYXRpb246IGNvbG9yQ2hhbmdlIDNzIGVhc2UtaW4tb3V0IGluZmluaXRlO1xufVxuXG4ubWVzc2FnZSBwIHtcbiAgZm9udC1zaXplOiAxLjVyZW07XG59XG5cbkBrZXlmcmFtZXMgY29sb3JDaGFuZ2Uge1xuICAwJSwgMTAwJSB7XG4gICAgY29sb3I6ICNmZmZmZmY7XG4gIH1cbiAgMzMlIHtcbiAgICBjb2xvcjogI2ZmZWIzYjtcbiAgfVxuICA2NiUge1xuICAgIGNvbG9yOiAjZmY0NDQ0O1xuICB9XG59XG5cbi8qIOeZu+WHuuaMiemIleaoo+W8jyAqL1xuLmxvZ291dC1idXR0b24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMnJlbTtcbiAgcmlnaHQ6IDJyZW07XG4gIHotaW5kZXg6IDEwO1xuICBwYWRkaW5nOiAwLjc1cmVtIDEuNXJlbTtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEpO1xuICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoMTBweCk7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4yKTtcbiAgYm9yZGVyLXJhZGl1czogMC41cmVtO1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlO1xuICBib3gtc2hhZG93OiAwIDRweCA2cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xufVxuXG4ubG9nb3V0LWJ1dHRvbjpob3ZlciB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4yKTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0ycHgpO1xuICBib3gtc2hhZG93OiAwIDZweCA4cHggcmdiYSgwLCAwLCAwLCAwLjE1KTtcbn1cblxuLmxvZ291dC1idXR0b246YWN0aXZlIHtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApO1xuICBib3gtc2hhZG93OiAwIDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xufVxuXG4vKiDpn7/mh4nlvI/oqK3oqIggKi9cbkBtZWRpYSAobWF4LXdpZHRoOiA2NDBweCkge1xuICAubG9nb3V0LWJ1dHRvbiB7XG4gICAgdG9wOiAxcmVtO1xuICAgIHJpZ2h0OiAxcmVtO1xuICAgIHBhZGRpbmc6IDAuNXJlbSAxcmVtO1xuICAgIGZvbnQtc2l6ZTogMC44NzVyZW07XG4gIH1cbn1cblxuLyog5bCK6YeN5L2/55So6ICF55qE5YuV55Wr5YGP5aW9ICovXG5AbWVkaWEgKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSkge1xuICAuc25vd2ZsYWtlLFxuICAuc3RhcixcbiAgLmxpZ2h0LFxuICAuZ2lmdCxcbiAgLm1lc3NhZ2UgaDEge1xuICAgIGFuaW1hdGlvbjogbm9uZTtcbiAgfVxufVxuPC9zdHlsZT5cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUF1QjtBQUNwQztBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUM7Ozs7Ozs7Ozs7O3FCQUlNLEtBQUssRUFBQyxxQkFBcUI7aUVBVzlCLG9CQUE2QixTQUF4QixLQUFLLEVBQUMsV0FBVzs7RUFHakIsS0FBSyxFQUFDLFlBQVk7RUFBQyxhQUFXLEVBQUMsTUFBTTs7Z0NBekI5QztpRUE4Rkksb0JBR00sU0FIRCxLQUFLLEVBQUMsU0FBUztlQUNsQixvQkFBbUIsWUFBZixZQUFVO2VBQ2Qsb0JBQXVCLFdBQXBCLGtCQUFnQjs7Ozt3QkFyRnZCLG9CQXVGTSxPQXZGTixVQXVGTTtJQXRGSiw2QkFBYTtJQUNiLG9CQU1TO01BTE4sT0FBSyxFQUFFLG1CQUFZO01BQ3BCLEtBQUssRUFBQyxlQUFlO01BQ3JCLFlBQVUsRUFBQyxJQUFJO09BQ2hCLE1BRUQ7SUFFQSw2QkFBYTtJQUNiLFVBQTZCO0lBRTdCLDZCQUFhO0lBQ2Isb0JBY00sT0FkTixVQWNNO3FCQWJKLG9CQVlNLGlCQXRDWixZQTJCb0IsRUFBRSxFQTNCdEIsQ0EyQmUsQ0FBQztlQURWLG9CQVlNO1VBVkgsR0FBRyxFQUFFLENBQUM7VUFDUCxLQUFLLEVBQUMsV0FBVztVQUNoQixLQUFLLEVBOUJkO21CQThCcUMsSUFBSSxDQUFDLE1BQU07NkJBQTBDLElBQUksQ0FBQyxNQUFNO3FDQUFpRCxJQUFJLENBQUMsTUFBTTs0QkFBd0MsSUFBSSxDQUFDLE1BQU07O1dBTTdNLEtBRUQ7OztJQUdGLDRCQUFZO0lBQ1osVUFpRE07SUFFTiw2QkFBYTtJQUNiLFVBR00ifQ==