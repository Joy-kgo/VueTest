import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/WelcomeScreen.vue");import { ref, onMounted } from "/node_modules/.vite/deps/vue.js?v=97a18dde"


const _sfc_main = {
  __name: 'WelcomeScreen',
  props: {
  username: {
    type: String,
    required: true
  }
},
  setup(__props, { expose: __expose }) {
  __expose();

const props = __props

const show = ref(true)

onMounted(() => {
  // 3秒後隱藏
  setTimeout(() => {
    show.value = false
  }, 3000)
})

const __returned__ = { props, show, ref, onMounted }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, Transition as _Transition, withCtx as _withCtx, createBlock as _createBlock, pushScopeId as _pushScopeId, popScopeId as _popScopeId } from "/node_modules/.vite/deps/vue.js?v=97a18dde"

const _withScopeId = n => (_pushScopeId("data-v-d23d33d0"),n=n(),_popScopeId(),n)
const _hoisted_1 = {
  key: 0,
  class: "welcome-overlay"
}
const _hoisted_2 = { class: "welcome-content" }
const _hoisted_3 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/_createElementVNode("h1", { class: "welcome-title" }, "歡迎登入！", -1 /* HOISTED */))
const _hoisted_4 = { class: "welcome-subtitle" }
const _hoisted_5 = /*#__PURE__*/ _withScopeId(() => /*#__PURE__*/_createElementVNode("div", { class: "welcome-icon" }, "🎄", -1 /* HOISTED */))

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createBlock(_Transition, { name: "fade" }, {
    default: _withCtx(() => [
      ($setup.show)
        ? (_openBlock(), _createElementBlock("div", _hoisted_1, [
            _createElementVNode("div", _hoisted_2, [
              _hoisted_3,
              _createElementVNode("p", _hoisted_4, _toDisplayString($props.username), 1 /* TEXT */),
              _hoisted_5
            ])
          ]))
        : _createCommentVNode("v-if", true)
    ]),
    _: 1 /* STABLE */
  }))
}

import "/src/components/WelcomeScreen.vue?vue&type=style&index=0&scoped=d23d33d0&lang.css"

_sfc_main.__hmrId = "d23d33d0"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-d23d33d0"],['__file',"D:/Tests/VueTest/tailwindCSS/vue-tailwindcss/src/components/WelcomeScreen.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiV2VsY29tZVNjcmVlbi52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cD5cbmltcG9ydCB7IHJlZiwgb25Nb3VudGVkLCBkZWZpbmVQcm9wcyB9IGZyb20gJ3Z1ZSdcblxuY29uc3QgcHJvcHMgPSBkZWZpbmVQcm9wcyh7XG4gIHVzZXJuYW1lOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIHJlcXVpcmVkOiB0cnVlXG4gIH1cbn0pXG5cbmNvbnN0IHNob3cgPSByZWYodHJ1ZSlcblxub25Nb3VudGVkKCgpID0+IHtcbiAgLy8gM+enkuW+jOmaseiXj1xuICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICBzaG93LnZhbHVlID0gZmFsc2VcbiAgfSwgMzAwMClcbn0pXG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8dHJhbnNpdGlvbiBuYW1lPVwiZmFkZVwiPlxuICAgIDxkaXYgdi1pZj1cInNob3dcIiBjbGFzcz1cIndlbGNvbWUtb3ZlcmxheVwiPlxuICAgICAgPGRpdiBjbGFzcz1cIndlbGNvbWUtY29udGVudFwiPlxuICAgICAgICA8aDEgY2xhc3M9XCJ3ZWxjb21lLXRpdGxlXCI+5q2h6L+O55m75YWl77yBPC9oMT5cbiAgICAgICAgPHAgY2xhc3M9XCJ3ZWxjb21lLXN1YnRpdGxlXCI+e3sgdXNlcm5hbWUgfX08L3A+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ3ZWxjb21lLWljb25cIj7wn46EPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgPC90cmFuc2l0aW9uPlxuPC90ZW1wbGF0ZT5cblxuPHN0eWxlIHNjb3BlZD5cbi53ZWxjb21lLW92ZXJsYXkge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzY2N2VlYSAwJSwgIzc2NGJhMiAxMDAlKTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHotaW5kZXg6IDk5OTk7XG59XG5cbi53ZWxjb21lLWNvbnRlbnQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYW5pbWF0aW9uOiBzbGlkZVVwIDAuNnMgZWFzZS1vdXQ7XG59XG5cbi53ZWxjb21lLXRpdGxlIHtcbiAgZm9udC1zaXplOiAzcmVtO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbn1cblxuLndlbGNvbWUtc3VidGl0bGUge1xuICBmb250LXNpemU6IDEuNXJlbTtcbiAgbWFyZ2luLWJvdHRvbTogMnJlbTtcbn1cblxuLndlbGNvbWUtaWNvbiB7XG4gIGZvbnQtc2l6ZTogNXJlbTtcbiAgYW5pbWF0aW9uOiBib3VuY2UgMXMgZWFzZS1pbi1vdXQgaW5maW5pdGU7XG59XG5cbkBrZXlmcmFtZXMgc2xpZGVVcCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgzMHB4KTtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIHRvIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufVxuXG5Aa2V5ZnJhbWVzIGJvdW5jZSB7XG4gIDAlLCAxMDAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7XG4gIH1cbiAgNTAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTIwcHgpO1xuICB9XG59XG5cbi5mYWRlLWVudGVyLWFjdGl2ZSwgLmZhZGUtbGVhdmUtYWN0aXZlIHtcbiAgdHJhbnNpdGlvbjogb3BhY2l0eSAwLjVzO1xufVxuXG4uZmFkZS1lbnRlci1mcm9tLCAuZmFkZS1sZWF2ZS10byB7XG4gIG9wYWNpdHk6IDA7XG59XG48L3N0eWxlPlxuIl0sIm1hcHBpbmdzIjoiQUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRDs7Ozs7Ozs7Ozs7O0FBRmM7QUFHZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FLWjtBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7O0VBakJGLEtBQUE7RUFzQnFCLEtBQUssRUFBQyxpQkFBaUI7O3FCQUNqQyxLQUFLLEVBQUMsaUJBQWlCO2lFQUMxQixvQkFBb0MsUUFBaEMsS0FBSyxFQUFDLGVBQWUsSUFBQyxPQUFLO3FCQUM1QixLQUFLLEVBQUMsa0JBQWtCO2lFQUMzQixvQkFBa0MsU0FBN0IsS0FBSyxFQUFDLGNBQWMsSUFBQyxJQUFFOzs7d0JBTGxDLGFBUWEsZUFSRCxJQUFJLEVBQUMsTUFBTTtJQXJCekIsa0JBc0JJLENBTU07T0FOSyxXQUFJO3lCQUFmLG9CQU1NLE9BTk4sVUFNTTtZQUxKLG9CQUlNLE9BSk4sVUFJTTtjQUhKLFVBQW9DO2NBQ3BDLG9CQUE4QyxLQUE5QyxVQUE4QyxtQkFBZixlQUFRO2NBQ3ZDLFVBQWtDOzs7VUExQjFDOztJQUFBLEdBQUEifQ==