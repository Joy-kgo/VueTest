import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue?vue&type=style&index=0&scoped=7a7a37b1&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "D:/Tests/VueTest/tailwindCSS/vue-tailwindcss/src/App.vue?vue&type=style&index=0&scoped=7a7a37b1&lang.css"
const __vite__css = "\r\n/* 移除原有的 logo 樣式（不再需要） */\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))